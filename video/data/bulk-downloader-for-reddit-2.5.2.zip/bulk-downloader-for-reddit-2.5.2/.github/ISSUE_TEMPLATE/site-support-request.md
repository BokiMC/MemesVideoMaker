---
name: Site Support request
about: Describe this issue template's purpose here.
title: "[SITE]"
labels: ''
assignees: ''

---

- [ ] I am requesting a site support.
- [ ] I am running the latest version of BDfR
- [ ] I have read the [Opening an issue](../../README.md#configuration)
  
## Site
Provide a URL to domain of the site.

## Example posts
Provide example reddit posts with the domain.
